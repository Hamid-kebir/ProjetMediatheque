<?php

define("HOST", "localhost");
define("USER", "root");
define("PASSWORD", "");
define("DATABASENAME", "mediatheque");


    define("__ADMIN", "admin98q4ZnPj658a");

    define("APP_KEY", "QaO0_F632Xcl856334");

    define("GOOGLE_API_KEY", "AIzaSyBJ64y6dbFeJtu5P6Ov8N_d5cSguZKYjWA");


    
     
    
