<?php



define("BASE_URL", base_url());


function bibliothecaireIsLogged($context = NULL){
    
    
    if($context!=NULL){
        
        
        $user = $context->session->admin;
        
        
        if(!empty($user)){
            return TRUE;
        }
        
        
    }
    
    
    return FALSE;
}

function bibliothecaireSession($context = NULL){
    
    
    if(isLogged($context)){
        return $context->session->admin;
    }
    
    return "";
    
}

function isLogged($context = NULL){
    
    
    if($context!=NULL){
        
        
        $user = $context->session->user;
        
        if( isset($user[0])){
            $user = $user[0];
        }
        
        if(!empty($user)){
            return TRUE;
        }
        
        
    }
    
    
    return FALSE;
}


function mYSession($context = NULL){
    
    
    if(isLogged($context)){
        $user = $context->session->user;
        return $user[0];
    }
    
    return "";
    
}



   
    
if ( ! function_exists('admin_url')){
    
    function admin_url($str=""){
        
        return BASE_URL."/".__ADMIN."/".$str;
    }
    
}
    
    
    
class Path{
    
    public static function getImagesBaseUrl(){
        return IMAGES_BASE_URL;
    }


    public static function getPath($t=array()){
        
        if(!empty($t)){
            $newpath = FCPATH;
            foreach ($t AS $v){
                
                if(preg_match("#\.#", $v) ){
                    $newpath.= $v;
                    return $newpath;
                }else{

                    $newpath.=$v._PATH;
                }
                
            }
            
            return $newpath;
        }
        
        return FCPATH;
    }
    
    public static function addPath($oldpath,$t=array()){
        
        
        if(!empty($t)){
            
            $lastc = substr($oldpath, -1);
            
            if($lastc!=_PATH){
                $oldpath.= _PATH;
            }
            
            $newpath = $oldpath;
            foreach ($t AS $v){
                
                if(preg_match("#\.#", $v) ){
                    $newpath.= $v;
                    return $newpath;
                }else{

                    $newpath.=$v._PATH;   
                }
                
            }
            
            return $newpath;
        }
        
        return $oldpath;
        
        
    }
}
    

//All mathods for text 
class Text{
    
    public static function input($str=""){
        
         return $str;
    }
    
    
    public static function output($str=""){
        
         return $str;
    }
    
    
    public static function setToArray($str="",$attrs=array()){
        
        $finaldate = array();
        
        if($str!=""){
            
            $data = explode(" ", $str);
            
           
             $i=0;
            foreach ($data as $value){
               
                foreach ($attrs as $value2){
                    
                    if(trim($value)!=""){
                        $finaldate[$i][trim($value2)] = trim($value);
                    }
                }
                
                 $i++;
            }
        }
        
      
      
        return $finaldate;
    }
    
    
    
    public static function preparedLikeStatement($data=array()){
       
        $str = "";
        $strfinal = "";
       
        if(!empty($data)){
          
            foreach($data AS $value){
           
                $i=0;
                $str = "";
                foreach ($value AS $key => $value2){
      
                    if($str!="")
                        $str = $str." OR ";

                    $str = $str."   $key like '%".  Text::input($value2)."%' ";
          
                }    
                
                if($strfinal!="")
                    $strfinal = $strfinal." AND ";
                    
                $strfinal = " ".$strfinal." (".$str.")";
            }
            
        }
        
       
        return $strfinal;
    }
    

    
}



class Json{
    
    
    
    public static function isJson($string) {
        json_decode($string);
        return (json_last_error() == JSON_ERROR_NONE);
    }
    
    
    public static function encode($str=""){
        return json_encode($str,JSON_FORCE_OBJECT);
    }

    
    public static function decode($str=""){
        return json_decode($str,JSON_FORCE_OBJECT);
    }

    public static function convertToJson($data=array(),$tag="default",$crypt=FALSE,$args=array()){
        
        $data = Json::prepareDataForJson($data,$crypt);
        $args = Json::prepareDataForJson($args,$crypt);
        
        
        
        return Json::encode(array("success"=>1,$tag=>$data,"args"=>$args));
    }

    public static function prepareDataForJson($data=array(),$crypt=FALSE){
        
        $newdata = array();
        
        if(is_array($data) AND !empty($data)){
            
            foreach ($data AS $key => $value){
                if(is_array($value)){
                    foreach ($value AS $key2 => $value2){
                        if($crypt==FALSE){
                            $newdata[$key][$key2] = Json::outputForJson($value2);
                        }else{
                            $newdata[$key][$key2] = Json::outputForJson(Security::encrypt($value2));
                        }
                    }
                }else{
                    if($crypt==FALSE)
                        {$newdata[$key] = Json::outputForJson($value);}
                    else
                        {$newdata[$key] = Json::outputForJson(Security::encrypt($value));}
                }
            }
            
        }
        
        return $newdata;
    }
    
    public static function setHeaderToJson(){
        
    }

    public static function outputForJson($str=""){
        
         return $str;
    }  
    
}



class Security{
    
     public static function cryptPassword($str=''){
        return sha1(sha1(md5(md5($str))));
    }
    
    
    public static function decrypt($str=""){
       
        return $str;
    }
    
    public static function cryptToken($str=""){
        return md5(sha1($str));
    }

    public static function encrypt($str=""){
        
        return $str;
    }
    
    //127.0.0.1
    //198.168.168.1
     public static function checkMacAddress($str=""){
        if($str!=""){
            if(preg_match("/^([a-fA-F0-9]{2}[:|\-|\.]?){6}$/i", $str)){
              
                return TRUE;
            }
        }
        
        
        return FALSE;
    }
    
    
    public static function checkIpAddress($str=""){
        if($str!=""){
            if(preg_match("/^([0-9]{3}[:|\-|\.]?){4}$/i", $str)){
              
                return TRUE;
            }
        }
        
        
        return FALSE;
    }
    
    public static function checkToken($str=""){
        if($str!=""){
            if(preg_match("/^[a-z0-9]+$/i", $str)){
              
                return TRUE;
            }
        }
        
        
        return FALSE;
    }
    
}



  
    
class Pagination{
    
    
    public $current_page;
    public $per_page;
    public $count;
    public $first_nbr;
    public $nbrpages;
    



    public function __construct() {
       
    }
        
        
    function getNbrpages() {
        return $this->nbrpages;
    }

    function setNbrpages($nbrpages) {
        $this->nbrpages = $nbrpages;
    }

            
    function getCurrent_page() {
        return $this->current_page;
    }

    function getPer_page() {
        return $this->per_page;
    }

    function getCount() {
        return $this->count;
    }

    function setCurrent_page($current_page) {
        
        if($current_page<=0){
            $current_page = 1;
        }
        
        $this->current_page = $current_page;
    }

    function setPer_page($per_page) {
        $this->per_page = $per_page;
    }

    function setCount($count) {
        $this->count = $count;
    }


        
    function getFirst_nbr() {
        return $this->first_nbr;
    }

    function setFirst_nbr($first_nbr) {
        $this->first_nbr = $first_nbr;
    }


        
    
    
    public function calcul(){

        
     
        //Nous allons maintenant compter le nombre de pages.
        if($this->count==0){
            $this->nbrpages = 1;
        }else{
              if($this->per_page>0){
                  $this->nbrpages=ceil($this->count/$this->per_page);
              }else{
                  $this->nbrpages = 1;
              }
            
        }
        
      
        
     
        if($this->nbrpages==0){ $this->nbrpages=1;}
      
        
        if(isset($this->current_page)) // Si la variable $_GET['page'] existe...
        {
             $this->current_page=intval($this->current_page);
             
             
               
             
             if($this->current_page>$this->nbrpages) // Si la valeur de $pageActuelle (le numéro de la page) est plus grande que $nombreDePages...
             {
                  $this->current_page=$this->nbrpages;
                 
             }
        }
        else // Sinon
        {
             $this->current_page=1; // La page actuelle est la n°1    
        }
        
      
      
     
        $this->first_nbr=($this->current_page-1)*$this->per_page;
        if($this->first_nbr<0)  {$this->first_nbr=0;}
        
    }
    
    
    
    
    
    public function links($data=array(),$page='',$uri=""){
          
        
     
        
        if($page==''){
            $url = $uri.Pagination::createUrl($data);
        }else{
            
      
            $url = $uri.Pagination::createUrl($data,$page);
            
          
            
        }
       
        
      
        
        $html = "";
        
        $html .= '<ul class="pagination">';
        
        
        if( ($this->current_page<=$this->nbrpages AND $this->current_page>1) ){
            
            
            if(empty($data)){
                $html .= '<li  class="paginate_button "><a href="'.$url.'page='.($this->current_page-1).'"><<</a></li>';
            }else{
                $html .= '<li  class="paginate_button "><a href="'.$url.'&page='.($this->current_page-1).'"><<</a></li>';
            }
           

            
        }
  
        
        $ini_nbr = intval($this->_pages($this->nbrpages,$this->current_page));
        
        
                if($ini_nbr<=$this->current_page AND $ini_nbr!=1) {$ini_nbr--;}
                           
                
		for($i=$ini_nbr;$i<=($ini_nbr+20);$i++){
                    
                        
                    
                   
                    
                            if($i!=$this->current_page){ 
                       
                                if(empty($data)){
                                    $html .= '<li  class="paginate_button "><a href="'.$url.'page='.($i).'">'.$i.'</a></li>';
                                }else{
                                    $html .= '<li class="paginate_button "><a href="'.$url.'&page='.($i).'">'.$i.'</a></li>';
                                }
                                    
                                      
                                        
                            }else{
                                $html .= '<li class="paginate_button active"><a>'.$i.'</a></li>';
                            }
                            if($i==$this->nbrpages) {break;} 
                     }
        
        
        if($this->current_page<$this->nbrpages){
            if(empty($data)){
                $html .= '<li><a href="'.$url.'page='.($this->current_page+1).'#">>></a></li>';
            }else{
                $html .= '<li><a href="'.$url.'&page='.($this->current_page+1).'#">>></a></li>';
            }
            
            
            
        }

        $html .= '</ul>';
        
        return $html;
          
    }
    
    
    
    private function _pages($pages,$current_page){

          
            if($current_page<=0){
                $current_page = 1;
            }
            
            
            
	if($pages>0){
            
        
            
            
                if(($current_page%10)==1) {   $r=$current_page; 	}
                else{
                     for($i=$current_page;$i>=1;$i--){
                        if( ( $i%10)==1 AND $pages>=$i){


                                    $r = $i;
                                    break;
                        }
                        }
                }
                
                
                if($pages>$r ){
                        $t = $r;
                        $ini = $r;
                }else{
                        $t = $r;
                        $ini = $r;							
                }
                return @$t;
                
            }	

        return 1;
       }
       
       
       
       
       public static function createUrl($data=array(),$page=''){
        
        
        
          if(!defined("PAGE")){
                define("PAGE", $page);
            }
        
         $url = "";
        if(!empty($data)){
            
            foreach ($data AS $key => $v){
                
              
                if($v!="" OR $v>0){ 
                   
                    if($url==""){
                       if($page==""){
                            $url .= PAGE."?";
                            
                       }else{
                           
                           
                           $url .= $page."?";
                       }
                    }else{
                        $url .="&";
                    }
                    
                    $url .= $key."=".$v;
                }
            }
        }
        
        if($url==""){
            if($page=="")
                 $url .= PAGE."?";
            else{
                $url .= $page."?";
            }
         }
        return $url;
    }
							
	
   }

