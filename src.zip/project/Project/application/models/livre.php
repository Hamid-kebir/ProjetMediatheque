<?php

class Livre extends CI_Model{
    
   
    public function getRes(){
        
        $id_res = intval($this->input->get("id_res"));
        
        $this->db->where("id_ressource",$id_res);
        
        $ressource = $this->db->get("ressource");
        
        $ressource = $ressource->result();
        
        return $ressource;
        
    }
    
     public function achter(){
        
        if(isLogged($this)){
            
            
            $res_id = intval($this->input->post("id"));
            $Id_abonne = mYSession($this)->Id_abonne;

            $this->db->where("id_abonne",$Id_abonne);
            $this->db->where("id_ressource",$res_id);
            
            $c = $this->db->count_all_results("fiche");
            
            if($c==1){
                //return array("success"=>-1);
            }else{
                
                $this->db->insert("fiche",array(
                    "id_abonne" => $Id_abonne,
                    "id_ressource"  =>$res_id
                ));
                
                $id = $this->db->insert_id();
                
                $this->db->insert("fiche_achat",array(
                    "id_fiche" => $id
                ));
                
                
               return array("success"=>1); 
            }

        
        }else{
            
            
        }
  
        
        return array("success"=>0);
        
    }
    
    
    public function reserver(){
        
         
        
        if(isLogged($this)){
            
        
           
            $res_id = intval($this->input->post("id"));
            $Id_abonne = mYSession($this)->Id_abonne;

            $this->db->where("id_abonne",$Id_abonne);
            $this->db->where("id_ressource",$res_id);
            
            $c = $this->db->count_all_results("fiche");
            
            if($c==1){
                return array("success"=>-1);
            }else{
                
                $id_fiche = time();
                $this->db->insert("fiche",array(
                    "id_fiche"  => $id_fiche,
                    "id_abonne" => $Id_abonne,
                    "id_ressource"  =>$res_id
                ));
                
                $id = $this->db->insert_id();
                
                $this->db->insert("fiche_reservation",array(
                    "id_fiche" => $id_fiche,
                    "date_reservation"  => date("Y-m-d",time())
                ));
                
                
                $this->db->where("id_ressource",$res_id);
                $this->db->update("ressource",array("Etat"=>1));
                
                
               return array("success"=>1); 
            }

        
        }else{
            
            return array("success"=>0);
        
        }
  
        
        
    }
    
    public function emprunter(){
        
        if(isLogged($this)){
            
            
            $res_id = intval($this->input->post("id"));
            $Id_abonne = mYSession($this)->Id_abonne;

            $this->db->where("id_abonne",$Id_abonne);
            $this->db->where("id_ressource",$res_id);
            
            $c = $this->db->count_all_results("fiche");
            
            if($c==1){
                return array("success"=>-1);
            }else{
                
                $this->db->insert("fiche",array(
                    "id_abonne" => $Id_abonne,
                    "id_ressource"  =>$res_id
                ));
                
                $id = $this->db->insert_id();
                
                $this->db->insert("fiche_emprunt",array(
                    "id_fiche" => $id,
                    "date_emprunt"  => date("Y-m-d",time())
                ));
                
                
                $this->db->where("id_ressource",$res_id);
                $this->db->update("ressource",array("Etat"=>1));
                
                
               return array("success"=>1); 
            }

        
        }else{
            
            
        }
  
        
        return array("success"=>0);
        
    }
    
    
    
    public function obtenirListeLivres(){
        
        $s = strip_tags(strtolower($this->input->get("s")));
        
        $page = intval($this->input->get("page"));
        
        
        
        
        $this->db->like("ressource.titre",$s);
        $this->db->select("ressource.*,livre.*");
 
        $this->db->join("livre","livre.Id_ressource=livre.id_ressource");
        
        $count = $this->db->count_all_results("ressource");
        
            $pagination = new Pagination();
            $pagination->setCount($count);
            $pagination->setCurrent_page($page);
            $pagination->setPer_page(50);

            $pagination->calcul();

        
            
            $this->db->like("ressource.titre",$s);
        $this->db->select("ressource.*,livre.*");
        $this->db->from("ressource");
        $this->db->join("livre","livre.Id_ressource=livre.id_ressource");
        
        
        
        $this->db->limit($pagination->getPer_page(),$pagination->getFirst_nbr());
        $this->db->order_by("ressource.id_ressource","DESC");
        $livres = $this->db->get();
        
        $data  = array();
        
        $data['data'] = $livres;
         $data['pagination'] = $pagination;
     
        
        
        return $data;     
        
    }
    
    
}
