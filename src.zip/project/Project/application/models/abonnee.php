<?php

class Abonnee extends CI_Model{
    
     public function login(){
        
        $errors = array();
        $data = array();
        
        $Password = $this->input->post("Password");
        $Email = $this->input->post("Email");
        
        
        
        //verification tous les champs 
        if($Password!=""){
            $data['Password'] = md5($Password);
        }else{
            $errors['Password'] = "Le champ mot de passe est vide !";
        }
      
        
        if($Email!=""){
        
            if(filter_var($Email,FILTER_VALIDATE_EMAIL)){
                $data['Email'] = $Email;
            }else{
                $errors['Email'] = "Email est invalide !";
            }
        }else{
            $errors['Email'] = "Le champ Email est vide !";
        }
     
        
        
        //verification email s'il deja existe
        if(empty($errors)){
            $this->db->where("Email",$Email);
            $this->db->where("Password",md5($Password));
            $count = $this->db->count_all_results("abonne");
            
            if($count==0){
                $errors['Identifiant'] = "Email ou mot de passe est incorrect! ";
            }
        }
        
        
        
        if(empty($errors)){
            
            //insert into table abonnee
             $this->db->where("Email",$Email);
            $this->db->where("Password",  md5($Password));
            $query = $this->db->get('abonne');
           
            //
            if($query->num_rows()>0){
                
                $this->session->set_userdata('user',$query->result());
                return array("success"=>1);
            }else{
                return array("success"=>0,"errors"=>$errors);
            }
            
            
        }
        
        
        return array("success"=>0,"errors"=>$errors);
        
    }
    
    
    public function inscription(){
        
        $errors = array();
        $data = array();
        
        $Password = $this->input->post("Password");
        $Nom = $this->input->post("Nom");
        $Prenom = $this->input->post("Prenom");
        $Age = $this->input->post("Age");
        $Email = $this->input->post("Email");
        $Adresse = $this->input->post("Adresse");
        $Tel = $this->input->post("Tel");
        
        
        
        //verification tous les champs 
        if($Password!=""){
            $data['Password'] = md5($Password);
        }else{
            $errors['Password'] = "Le champ mot de passe est vide !";
        }
        
        if($Nom!=""){
            $data['Nom'] = $Nom;
        }else{
            $errors['Nom'] = "Le champ Nom est vide !";
        }
        
        
        if($Prenom!=""){
            $data['Prenom'] = $Prenom;
        }else{
            $errors['Prenom'] = "Le champ Prenomest vide !";
        }
        
        
        if($Age!=""){
            $data['Age'] = $Age;
        }else{
            $errors['Age'] = "Le champ Age est vide !";
        }
        
        
        if($Email!=""){
        
            if(filter_var($Email,FILTER_VALIDATE_EMAIL)){
                $data['Email'] = $Email;
            }else{
                $errors['Email'] = "Email est invalide !";
            }
        }else{
            $errors['Email'] = "Le champ Email est vide !";
        }
        
        if($Adresse!=""){
            $data['Adresse'] = $Adresse;
        }else{
            $errors['Adresse'] = "Le champ Adresse est vide !";
        }
        
        if($Tel!=""){
            $data['Tel'] = $Tel;
        }else{
            $errors['Tel'] = "Le champ Tel est vide !";
        }
        
        
        //verification email s'il deja existe
        if(empty($errors)){
            $this->db->where("Email",$Email);
            $count = $this->db->count_all_results("abonne");
            
            if($count>0){
                $errors['Email'] = "Votre email qui vous avez saisissez est deja existe";
            }
        }
        
        
        
        if(empty($errors)){
            
            //insert into table abonnee
            $this->db->insert("abonne",$data);
            
            $id_abonnee = $this->db->insert_id();
            
            $query = $this->db->get_where('abonne', array('Id_abonne' => $id_abonnee));
           
            //
            if($query->num_rows()>0){
                
                $this->session->set_userdata('user',$query->result());
                return array("success"=>1);
            }else{
                return array("success"=>0,"errors"=>$errors);
            }
            
            
        }
        
        
        return array("success"=>0,"errors"=>$errors);
        
    }
    
    
}
