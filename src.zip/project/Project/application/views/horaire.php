<?php $this->load->view("includes/header"); ?>
  
  
							<h1 class="titre"> Horaires </h1> <br> <br>
  
							<p class="h2m_titre"> <span class="h2m"> H2M </span> Médiathèque </p>
							
							<hr class="lignehr" align="left"/>
							
							<ul class="list-group" id="liste">
								<li class="list-group-item list-group-item-info"> Lundi : 10h00 - 13h00 </li> <br>	
								<li class="list-group-item list-group-item-info"> Mardi : 14h00 - 18h30 </li> <br>
								<li class="list-group-item list-group-item-info"> Mercredi : 10h00 - 13h00 et 14h00 - 18h30</li> <br>
								<li class="list-group-item list-group-item-info"> Jeudi : 14h00 - 18h30 </li> <br>
								<li class="list-group-item list-group-item-info"> Vendredi : 14h00 - 18h30 </li> <br>
								<li class="list-group-item list-group-item-info"> Samedi : 10h00 - 13h00 et 14h00 - 18h30 </li> <br>
								<li class="list-group-item list-group-item-info"> Dimanche: En alternance avec la médiathèque des Ulis </li> <br> <br>
	
								<p class="texte"> <img src="<?=  base_url("icone-attention.jpg")?>"/>- Durant les vacances de printemps la médiathèque est ouverte aux horaires habituels.</p>

							</ul>
							
  <!-- Footer   -->	
<footer class="footer-distributed">

					<div class="footer-left">

							<h3>Médiathèque<span>H2M</span></h3>

							<p class="footer-links">
							
								<a href="#">Accueil</a>
					
								<a href="#">A propos</a>
					
								<a href="#">FAQ</a>
					
								<a href="#">Contact</a>
							</p>

							<p class="footer-company-name">H2M Médiathèque &copy; 2018</p>
					</div>

					<div class="footer-center">

						<div>
							<i class="fa fa-map-marker"></i>
							<p><span>Batiment 640 PUIO</span> Saclay, France</p>
						</div>

						<div>
							<i class="fa fa-phone"></i>
							<p>+33 7 52 82 54 62</p>
						</div>

						<div>
							<i class="fa fa-envelope"></i>
							<p><a href="mailto:echaimae.ou@gmail.com">echaimae.ou@gmail.com </a></p>
						</div>

					</div>

					<div class="footer-right">

							<p class="footer-company-about">
							<span>A propos du site</span>
							Bienvenue dans votre médiathèque! H2m est une médiathèque ouverte à tous public, elle vous
							offre plusieurs services et vous permet de rester en contact avec la littérature et la culture.
							</p>

					</div>

</footer>
  
  </body>
</html>
