<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="icone_h2m.jpg">

    <title>Documents Administratifs - Médiathèque H2M</title>

    
  
	
    <!-- Custom styles for this template -->
    <link href="starter-template.css" rel="stylesheet">
	<link href="bootstrap.css" rel="stylesheet">
	<link href="assets/css/font-awesome.css" rel="stylesheet">
	<script src="jquery.js"></script>
	<script src="bootstrap.min.js"></script>
	<script src="assets/js/jquery-1.11.1.js"></script>
	<script src="assets/js/custom.js"></script>

	

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  
  <body>
			<h1 class="titre"> Documents Administratifs </h1> <br> <br>
			<p class="h2m_titre"> <span class="h2m"> H2M </span> Médiathèque </p>
			<hr class="lignehr" align="left"/>
			<p> Préparez votre visite dans le réseau en téléchargeant les formulaires nécessaires pour l'inscription . Vous retrouvez également tous les documents pourrant vous être utiles. </p> <br>
  
			<ul class="list-group" id="liste">
				<li class="list-group-item list-group-item-info"> <a href="Charte Internet.pdf" target="_blank"> Charte Internet & Multimédia de la médiathèque H2M.</a> </li> <br>	
				<li class="list-group-item list-group-item-info"> <a href="Réglement intérieur.pdf" target="_blank"> Régelement intérieur de la médiathèque H2M. </a> </li> <br>	
			</ul>
   
   
  
<!-- Footer   -->	
<footer class="footer-distributed">

					<div class="footer-left">

							<h3>Médiathèque<span>H2M</span></h3>

							<p class="footer-links">
							
								<a href="#">Accueil</a>
					
								<a href="#">A propos</a>
					
								<a href="#">FAQ</a>
					
								<a href="#">Contact</a>
							</p>

							<p class="footer-company-name">H2M Médiathèque &copy; 2018</p>
					</div>

					<div class="footer-center">

						<div>
							<i class="fa fa-map-marker"></i>
							<p><span>Batiment 640 PUIO</span> Saclay, France</p>
						</div>

						<div>
							<i class="fa fa-phone"></i>
							<p>+33 7 52 82 54 62</p>
						</div>

						<div>
							<i class="fa fa-envelope"></i>
							<p><a href="mailto:echaimae.ou@gmail.com">echaimae.ou@gmail.com </a></p>
						</div>

					</div>

					<div class="footer-right">

							<p class="footer-company-about">
							<span>A propos du site</span>
							Bienvenue dans votre médiathèque! H2m est une médiathèque ouverte à tous public, elle vous
							offre plusieurs services et vous permet de rester en contact avec la littérature et la culture.
							</p>


					</div>

</footer>
  
  </body>

</html>
