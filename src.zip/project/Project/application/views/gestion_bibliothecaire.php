<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="icone_h2m.jpg">

	
    <!-- Custom styles for this template -->
    <link href="starter-template.css" rel="stylesheet">
	<link href="bootstrap.css" rel="stylesheet">
	<link href="assets/css/font-awesome.css" rel="stylesheet">
	<script src="jquery.js"></script>
	<script src="bootstrap.min.js"></script>
	<script src="assets/js/jquery-1.11.1.js"></script>
	<script src="assets/js/custom.js"></script>

	
	<!-->
    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  
  <body>
					<h1 class="titre_iframe"> Gestion des bibliothécaires </h1>
					
					<table class="longueur_champ" width=100%>
						<tr align="center">
							<td>
								<form method="get">
									<fieldset class="form-group">
										<label for="id_bibliothecaire">Identifiant bibliothécaire :</label>
										<input type="text" class="form-control" id="id_bibliothecaire" placeholder="Identifiant bibliothécaire" >
									</fieldset>
	
 
									<fieldset class="form-group">
										<label for="mdp">Mot de passe :</label>
										<input type="text" class="form-control" id="mdp" placeholder="Mot de passe" >
									</fieldset>
  
  
									<fieldset class="form-group">
										<label for="nom">Nom :</label>
										<input type="text" class="form-control" id="nom" placeholder="Nom" >
									</fieldset>
  
  
									<fieldset class="form-group">
										<label for="prenom">Prénom :</label>
										<input type="text" class="form-control" id="prenom" placeholder="Prénom" >
									</fieldset>
  
  
   
									<fieldset class="form-group">
										<label for="age">Age :</label>
										<input type="text" class="form-control" id="age" placeholder="Age" >
									</fieldset>
  
   
									<fieldset class="form-group">
										<label for="tel">Téléphone :</label>
										<input type="text" class="form-control" id="tel" placeholder="Téléphone" >
									</fieldset>
   
   
									<fieldset class="form-group">
										<label for="email">Email :</label>
										<input type="text" class="form-control" id="email" placeholder="Email" >
									</fieldset>
  
   
									<fieldset class="form-group">
										<label for="adresse">Adresse :</label>
										<input type="text" class="form-control" id="etat" placeholder="Adresse" >
									</fieldset>
  
   
									<fieldset class="form-group">
										<label for="code_postal">Code postal :</label>
										<input type="text" class="form-control" id="code_postal" placeholder="Code postal" >
									</fieldset>
  
   
									<fieldset class="form-group">
										<label for="ville">Ville :</label>
										<input type="text" class="form-control" id="ville" placeholder="Ville" >
									</fieldset> 
							</td>
							<br> <br>
							<td align="center">  
									<fieldset class="form-group" >
										<input class="btn btn-custom-ajouter" style="font-family:Segoe UI;font-size:20px;font-weight:bold" id="style_bouton" type="button" value="Ajouter">
									</fieldset>
  
   
									<fieldset class="form-group">
										<input class="btn btn-custom"  style="font-family:Segoe UI;font-size:20px;font-weight:bold" id="style_bouton" type="button" value="Modifier">
									</fieldset>

   
									<fieldset class="form-group">
										<input class="btn btn-custom-supprimer" style="font-family:Segoe UI;font-size:20px;font-weight:bold" id="style_bouton" type="button" value="Supprimer">
									</fieldset>

   
									<fieldset class="form-group">
										<input class="btn btn-custom-vider" style="font-family:Segoe UI;font-size:20px;font-weight:bold" id="style_bouton" type="button" value="Vider">
									</fieldset>
  
  
									<fieldset class="form-group">
											<table align="right" style="margin-left:80px;">
												<tr>
													<td>
														<input type="text" class="form-control" id="rechercher" placeholder="Rechercher par ID" >
													</td>
													<td id="param_bouton">
														<input type="button" class="form-control" id="image_rechercher_input" name="rechercher" value="">
													</td>
												</tr>
											</table>
									</fieldset>
								
								</form>
							</td>
						</tr>
 
				</table>
  </body>
  </html>
