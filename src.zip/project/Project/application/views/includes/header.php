<!DOCTYPE html>
<html lang="fr">
  <head>
      
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?=  base_url("template/icone_h2m.jpg ")?>">

    <title>Médiathèque H2M</title>

	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <!-- Custom styles for this template -->
    <link href="<?=  base_url("template/bootstrap.css")?>" rel="stylesheet">
	<link href="<?=  base_url("template/assets/css/font-awesome.css")?>" rel="stylesheet">
    <link href="<?=  base_url("template/starter-template.css")?>" rel="stylesheet">
	<script src="<?=  base_url("template/jquery.js")?>"></script>
	<script src="<?=  base_url("template/bootstrap.min.js")?>"></script>
	<script src="<?=  base_url("template/assets/js/jquery-1.11.1.js")?>"></script>
	<script src="<?=  base_url("template/assets/js/custom.js")?>"></script>

	

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="<?=  base_url("template/assets/js/ie-emulation-modes-warning.js")?>"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>
  
								<div>
									<header class="row">
										<div class="col-lg-12">
										<img src="<?=  base_url("template/library.jpg ")?>" alt="Library" class="photo">
										</div>
								
                                                                </div>
      
      
      
      

								
								<div class="navbar navbar-inverse ">
									<div class="container">
										<div class="navbar-header">
											<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
												<span class="sr-only"></span>
												<span class="icon-bar"></span>
												<span class="icon-bar"></span>
												<span class="icon-bar"></span>
											</button>
											<a class="navbar-brand" href="#">Médiathèque H2M</a>
										</div>
		
		
										<div id="navbar" class="collapse navbar-collapse" >		
											<ul class="nav navbar-nav" >
												<li class="active"> <a href="#"> Accueil </a> </li>
												<li class="dropdown"> 
													<a data-toggle="dropdown" href="#"> Pratique <b class="caret"> </b> </a>
													<ul class="dropdown-menu">
                                                                                                            <li><a href="<?=  site_url("home/horaire")?>">Horaires</a></li>
														<li><a href="<?=  site_url("home/venir")?>">Venir</a></li>
                                                                                                                
                                                                                                                <?php if(!isLogged($this)){ ?>
                                                                                                                                    <li>
                                                                                                                                    
                                                                                                                                    
                                                                                                                                     <a data-toggle="modal"  data-dismiss="modal" href="#ModalInscription">Inscription</a>
                                                                                                                                    </li>
                                                                                                                                    <li>
                                                                                                                                    
                                                                                                                                    
                                                                                                                                     <a data-toggle="modal"  data-dismiss="modal" href="#ModalLogin">Se connecter</a>
                                                                                                                                    </li>
                                                                                                                <?php }else{ ?>
                                                                                                                                    
                                                                                                                          <li>
                                                                                                                                    
                                                                                                                                    
                                                                                                                              <a href="<?=  site_url("home/deconnecter")?>">Se deconnecter</a>
                                                                                                                                    </li>           
                                                                                                                                    
                                                                                                                <?php } ?>
														<li><a href="<?=  site_url("home/coordonnees")?>">Coordonnées</a></li>		  
														<li class="divider"></li>
														<li><a href="<?=  site_url("home/document_admin")?>">Documents Administratifs</a></li>
													</ul>
												</li>
				
												<li class="dropdown"> 
													<a data-toggle="dropdown" href="#"> Catalogue <b class="caret"> </b> </a>
													<ul class="dropdown-menu">
														<li><a href="#">Nos suggestions</a></li>
														<li><a href="<?=  site_url("home/rayon")?>">Comment retrouver un document en rayon</a></li>
														<li><a href="#">Nouveautés</a></li>
													</ul>
												</li>
		  
												<li class="dropdown"> 
													<a data-toggle="dropdown" href="#"> Le Réseau <b class="caret"> </b> </a>
													<ul class="dropdown-menu">
														<li><a href="<?=  site_url("home/mission")?>">Mission</a></li>
														<li><a href="http://www.bibliotheques.u-psud.fr/fr/index.html" target="_blank">Bibliothèque Universitaire Paris-SUD</a></li>
														<li class="divider"></li>
														<li><a href="http://www.lesulis.fr/loisirs/culture/la-mediatheque-francois-mitterrand.htm" target="_blank">Médiathèque Les Ulis</a></li>
														<li><a href="http://www.bpi.fr/home.html" target="_blank">Médiathèque Pampidou</a></li>
														<li><a href="http://mediatheque.clamart.fr/" target="_blank">Médiathèque de clamart</a></li> 
													</ul> 
												</li>
		  
                                                                                                <!--
												<li class="dropdown"> 
													<a data-toggle="dropdown" href="#"> Aide <b class="caret"> </b> </a>
													<ul class="dropdown-menu">
														<li><a href="#">Guide du portail</a></li>
														<li><a href="#">Questions/Réponses</a></li> 
													</ul> 
												</li>-->
                                                                                                
                                                                                                
                                                                                                <li> <a href="<?=  site_url("admin/bibliothecaire/gestion_ressource")?>">Admin </a> </li>
		  
											</ul>
											
                                                                                    <form class="navbar-form navbar-right inline-form" action="<?=  site_url("home/resultat")?>">
												<div class="form-group">
                                                                                                    <input type="search" name="s" class="input-sm form-control" placeholder="Recherche">
													<button type="submit" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-eye-open"></span> Chercher</button>
												</div>
											</form>	
											
										</div> <!--/.nav-collapse -->	
									</div>
								</div>
  <div class="modal signUpContent fade" id="ModalInscription" tabindex="-1" role="dialog" >
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> &times; </button>
        <h3 class="modal-title-site text-center" > INSCRIPTION </h3>
      </div>
      <div class="modal-body">
       
          
       <form action="page/inscription" method="post">
           
        <div class="form-group reg-username">
          <div >
            <input name="Nom"  class="form-control input"  size="20" placeholder="Nom" type="text">
          </div>
        </div>
           
           <div class="form-group reg-username">
          <div >
            <input name="Prenom"  class="form-control input"  size="20" placeholder="Prenom" type="text">
          </div>
        </div>
           
           <div class="form-group reg-username">
          <div >
            <input name="Age"  class="form-control input"  size="20" placeholder="Age" type="text">
          </div>
        </div>
        <div class="form-group reg-username">
          <div >
            <input name="Email"  class="form-control input"  size="20" placeholder="Email" type="text">
          </div>
        </div>
        <div class="form-group reg-email">
          <div >
            <input name="Adresse"  class="form-control input"  size="20" placeholder="Adresse postal" type="text">
          </div>
        </div>
        <div class="form-group reg-password">
          <div >
              <input name="Tel"  class="form-control input"  size="20" placeholder="Telephone" type="text">
          </div>
        </div>
           
           <div class="form-group reg-password">
          <div >
              <input name="Password"  class="form-control input"  size="20" placeholder="Mot de passe" type="password">
          </div>
        </div>
        <div class="form-group">
          <div >
            <div class="checkbox login-remember">
           
            </div>
          </div>
        </div>
        <div >
          <div >
              <input name="submit" id="signup" class="btn  btn-block btn-lg btn-primary" value="Continuer" type="submit">
          </div>
        </div>
      </form>     
          
        <!--userForm--> 
        
      </div>
      <div class="modal-footer">
        <p class="text-center"> <a data-toggle="modal"  data-dismiss="modal" href="#ModalLogin"> Se connecter </a> </p>
      </div>
    </div>
    <!-- /.modal-content --> 
    
  </div>
  <!-- /.modal-dialog --> 
  
</div>
      
      
<div class="modal signInContent fade" id="ModalLogin" tabindex="-1" role="dialog" >
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> &times; </button>
        <h3 class="modal-title-site text-center" > CONNEXION </h3>
      </div>
      <div class="modal-body">
       
          
       <form action="page/inscription" method="post">
           
        
        <div class="form-group reg-username">
          <div >
            <input name="Email"  class="form-control input"  size="20" placeholder="Email" type="text">
          </div>
        </div>
       
           
           <div class="form-group reg-password">
          <div >
              <input name="Password"  class="form-control input"  size="20" placeholder="Mot de passe" type="password">
          </div>
        </div>
        <div class="form-group">
          <div >
            <div class="checkbox login-remember">
           
            </div>
          </div>
        </div>
        <div >
          <div >
              <input name="submit" id="login" class="btn  btn-block btn-lg btn-primary" value="Se connecter" type="submit">
          </div>
        </div>
      </form>     
          
        <!--userForm--> 
        
      </div>
      <div class="modal-footer">
        <p class="text-center"> <a data-toggle="modal"  data-dismiss="modal" href="#ModalLogin"> Se connecter </a> </p>
      </div>
    </div>
    <!-- /.modal-content --> 
    
  </div>
  <!-- /.modal-dialog --> 
  
</div>
      
      
      <script>
      
            $(".signInContent #login").on('click',function(){
                
                var args = {
                    "Password":$(".signInContent input[name=Password]").val(),
                    "Email":$(".signInContent input[name=Email]").val()
                }
                
                
                $.ajax({
                    url:"<?=  site_url("ajax/login")?>",
                    data:args,
                    dataType: 'json',
                    type: 'POST',
                    beforeSend: function (xhr) {
                        $(".signInContent  #signup").attr("disabled",true);
                    },
                    success: function (data, textStatus, jqXHR) {
                        
                        $(".signInContent  #signup").attr("disabled",false);
                        
                        
                      
                        if(data.success===1){
                            document.location.reload();
                        }else{
                            var strError = "";
                            for(var key in data.errors){
                                strError = key+"# "+data.errors[key]+"\n";
                            }
                            
                            alert(strError);
                        }
                        
                        console.log(data);
                        
                    },error: function (jqXHR, textStatus, errorThrown) {
                        console.log(jqXHR);
                        alert("Error:\n"+jqXHR.responseText);
                        $(".signInContent  #signup").attr("disabled",false);
                    }
                });
                
                return false;
            });
      
      
      </script>
      
      
      <script>
      
            $(".signUpContent #signup").on('click',function(){
                
                var args = {
                    "Password":$(".signUpContent input[name=Password]").val(),
                    "Nom":$(".signUpContent input[name=Nom]").val(),
                    "Prenom":$(".signUpContent input[name=Prenom]").val(),
                    "Age":$(".signUpContent input[name=Age]").val(),
                    "Email":$(".signUpContent input[name=Email]").val(),
                    "Adresse":$(".signUpContent input[name=Adresse]").val(),
                    "Tel":$(".signUpContent input[name=Tel]").val(),
                }
                
                
                $.ajax({
                    url:"<?=  site_url("ajax/inscription")?>",
                    data:args,
                    dataType: 'json',
                    type: 'POST',
                    beforeSend: function (xhr) {
                        $(".signUpContent #signup").attr("disabled",true);
                    },
                    success: function (data, textStatus, jqXHR) {
                        
                        $(".signUpContent #signup").attr("disabled",false);
                        
                        
                      
                        if(data.success===1){
                            document.location.reload();
                        }else{
                            var strError = "";
                            for(var key in data.errors){
                                strError = key+"# "+data.errors[key]+"\n";
                            }
                            
                            alert(strError);
                        }
                        
                        
                    },error: function (jqXHR, textStatus, errorThrown) {
                        console.log(jqXHR);
                        alert("Error:\n"+jqXHR.responseText);
                        $(".signUpContent #signup").attr("disabled",false);
                    }
                });
                
                return false;
            });
      
      
      </script>