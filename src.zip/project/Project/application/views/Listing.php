<html lang="fr">
<head>
    
    <base href="<?=  base_url()?>"/>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="icone_h2m.jpg">

    <title>Listing - Médiathèque H2M</title>

    <!-- Custom styles for this template -->
    <link href="<?=  base_url("template/starter-template.css")?>" rel="stylesheet">
	<link href="<?=  base_url("template/bootstrap.css")?>" rel="stylesheet">
	<link href="<?=  base_url("template/assets/css/font-awesome.css")?>" rel="stylesheet">
	<script src="<?=  base_url("template/jquery.js")?>"></script>
	<script src="<?=  base_url("template/bootstrap.min.js")?>"></script>
	<script src="<?=  base_url("template/assets/js/jquery-1.11.1.js")?>"></script>
	<script src="<?=  base_url("template/assets/js/custom.js")?>"></script>

	

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="<?=  base_url("template/assets/js/ie-emulation-modes-warning.js")?>"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  
  <body>

<table class="table table-bordered table-striped table-condensed">
   <caption>
      <h4 style="font-size:30px;">Résultat(s) de votre recherche: <?=count($result['data']->result())?> Livre(s)</h4>
      
       <form class="navbar-form inline-form" action="<?=  site_url("home/resultat")?>">
           <label>Recherche: </label><input style="width: 270px" value="<?=  htmlentities($this->input->get("s"))?>" type="search" name="s" class="input-sm form-control" placeholder="Recherche">
           <button type="submit">ok</button>
</form>
      
	  <br> <br>
	  <h4 style="font-family:SegoeUI;">Indications: </h4>
	  
	  <p style="font-weight:bold; color:rgb(105,137,222)"> 
		<img src="<?=  base_url("template/icone_reserver.jpg")?>" /> : Réserver 
		<img src="<?=  base_url("template/icone_emprunter.jpg")?>" /> : Emprunter 
		<img src="<?=  base_url("template/icone_achat.jpg")?>" /> : Acheter 	
	 </p>
	  
   </caption>
   <thead>
      <tr>
            <th>Type de ressource </th>
            <th> Titre</th>
			<th> Auteur</th>
			<th> Titre</th>
			<th> Prix</th>
			
			<th> Etat</th>
			<th> Opération</th>
      </tr>
   </thead>
   
   
<?php if(count($result['data']->result()>0)){ ?>   
   
   <tbody>
       
       <?php foreach ($result['data']->result() AS $livre) { ?>
        <tr>
            <td></td>
            <td><?=$livre->titre?></td>
			<td><?=$livre->auteur?></td>
			<td><?=$livre->titre?></td>
			<td><?=$livre->Prix?></td>
			
			<td><?php
                            if($livre->Etat==1){
                                echo "<span style='color:#27a70e'>Reservé</span>";
                            }else{
                                echo "<span>Non-Reservé</span>";
                            }
                        
                        ?></td>
			<td>
                            
                            <?php if($livre->Etat==0){?>
                            <a id="reserver" href="<?=  site_url("home/detail/reserver_ressource?id_res=".$livre->id_ressource)?>" data="<?=$livre->id_ressource?>">Réserver</a>&nbsp;|&nbsp;
                            <a  id="emprunter"  href="<?=  site_url("home/detail/emprunter_ressource?id_res=".$livre->id_ressource)?>"  data="<?=$livre->id_ressource?>" >Emprunter </a>&nbsp;|&nbsp;
                            <a id="achter"  href="<?=  site_url("home/detail/acheter_ressource?id_res=".$livre->id_ressource)?>"   data="<?=$livre->id_ressource?>" >Acheter</a>
                            <?php } ?>
		</td>				
	</tr>
       <?php } ?>
			
		  
    </tbody>
	
<?php } ?>
	</body>
</table>
      
      <?php
                                  
                                  $pagination = $result['pagination'];
                                  
                                  $getting = array(
                                      "date" => $this->input->get("date")
                                  );
                                 
                                  echo $pagination->links($getting,null, current_url());
                                    
                                  ?>
      
      
      
      
<div class="modal content fade" id="Action" tabindex="-1" role="dialog" >
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> &times; </button>
        <h3 class="modal-title-site text-center" > RESERVER </h3>
      </div>
      <div class="modal-body">
       
          
       Votre reservation a ete bien effectue    
          
        <!--userForm--> 
        
      </div>
     
    </div>
    <!-- /.modal-content --> 
    
  </div>
  <!-- /.modal-dialog --> 
</div>
  
</div>

<!--
<script>
    
    $(".table #reserver").on('click',function(){
       
        $.ajax({
            url:"<?=  site_url("ajax/reserver")?>",
            data:{"id":$(this).attr("data")},
            dataType: 'json',
            type: 'POST',
            beforeSend: function (xhr) {
                        
            },
            success: function (data, textStatus, jqXHR) {
                console.log(data);
                 if(data.success===1){
                     
                     
                 }else if(data.success===-1){ 
                     
                      alert("Vous avez deja reserve ce livre");
                     
                 }else if(data.success===0){
                     
                     alert("if faut connecter avant");
                 }
                     
             }
        });
        
        return false;
    });
    
    $(".table #emprunter").on('click',function(){
       
        $.ajax({
            url:"<?=  site_url("ajax/emprunter")?>",
            data:{"id":$(this).attr("data")},
            dataType: 'json',
            type: 'POST',
            beforeSend: function (xhr) {
                        
            },
            success: function (data, textStatus, jqXHR) {
                console.log(data);
                 if(data.success===1){
                     
                     
                 }else if(data.success===-1){ 
                     
                      alert("Vous avez deja emprunter ce livre");
                     
                 }else if(data.success===0){
                     
                     alert("if faut connecter avant");
                 }
                     
             }
        });
        
        return false;
    });
    
    $(".table #achter").on('click',function(){
       
        $.ajax({
            url:"<?=  site_url("ajax/achter")?>",
            data:{"id":$(this).attr("data")},
            dataType: 'json',
            type: 'POST',
            beforeSend: function (xhr) {
                        
            },
            success: function (data, textStatus, jqXHR) {
                console.log(data);
                 if(data.success===1){
                     
                     
                 }else if(data.success===-1){ 
                     
                      alert("Vous avez deja achte ce livre");
                     
                 }else if(data.success===0){
                     
                     alert("if faut connecter avant");
                 }
                     
             }
        });
        
        return false;
    });
    
    
</script>

-->
  