<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="icone_h2m.jpg">

    <title>Client - Médiathèque H2M</title>

   	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <!-- Custom styles for this template -->
    <link href="<?=  base_url("template/bootstrap.css")?>" rel="stylesheet">
	<link href="<?=  base_url("template/assets/css/font-awesome.css")?>" rel="stylesheet">
    <link href="<?=  base_url("template/starter-template.css")?>" rel="stylesheet">
	<script src="<?=  base_url("template/jquery.js")?>"></script>
	<script src="<?=  base_url("template/bootstrap.min.js")?>"></script>
	<script src="<?=  base_url("template/assets/js/jquery-1.11.1.js")?>"></script>
	<script src="<?=  base_url("template/assets/js/custom.js")?>"></script>

	 <script src="<?=  base_url("template/assets/js/ie-emulation-modes-warning.js")?>"></script>

	

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body>
						<div>
							<header class="row">
								<div class="col-lg-12">
                                                                    <img src="<?=  base_url("template/library.jpg")?>" alt="Library" class="photo">
								</div>
						</div>

						<div class="navbar navbar-inverse ">
							<div class="container">
								<div class="navbar-header">
									<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
										<span class="sr-only"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
                                                                    <a class="navbar-brand" href="<?=  site_url()?>">Médiathèque H2M</a>
								</div>
		
								<div id="navbar" class="collapse navbar-collapse" >		
									<ul class="nav navbar-nav" >
                                                                            <li > <a  href="<?=  site_url("home/detail/reserver_ressource?id_res=".intval($this->input->get("id_res")))?>"> Réserver une ressource </a> </li>
										<li > <a  href="<?=  site_url("home/detail/acheter_ressource?id_res=".intval($this->input->get("id_res")))?>"> Acheter une ressource </a> </li>
										<li > <a href="<?=  site_url("home/detail/emprunter_ressource?id_res=".intval($this->input->get("id_res")))?>"> Emprunter une ressource </a> </li>			
									</ul>		
								</div>
							</div>
						</div>
		
      <div class="row" style="margin: 20px;">
							<?php
          
                                                                                        $uri = $this->uri->segment(3);


                                                                                        if($uri=="reserver_ressource")
                                                                                            $this->load->view("reserver_ressource");
                                                                                        else if($uri=="acheter_ressource")
                                                                                            $this->load->view("acheter_ressource");
                                                                                        else if($uri=="emprunter_ressource")
                                                                                            $this->load->view("emprunter_ressource");
                                                                                        


                                                                                  ?>
                                                
                                                                        </div>
		
<!-- Footer   -->	
<footer class="footer-distributed">

					<div class="footer-left">

							<h3>Médiathèque<span>H2M</span></h3>

							<p class="footer-links">
							
								<a href="#">Accueil</a>
					
								<a href="#">A propos</a>
					
								<a href="#">FAQ</a>
					
								<a href="#">Contact</a>
							</p>

							<p class="footer-company-name">H2M Médiathèque &copy; 2018</p>
					</div>

					<div class="footer-center">

						<div>
							<i class="fa fa-map-marker"></i>
							<p><span>Batiment 640 PUIO</span> Saclay, France</p>
						</div>

						<div>
							<i class="fa fa-phone"></i>
							<p>+33 7 52 82 54 62</p>
						</div>

						<div>
							<i class="fa fa-envelope"></i>
							<p><a href="mailto:echaimae.ou@gmail.com">echaimae.ou@gmail.com </a></p>
						</div>

					</div>

					<div class="footer-right">

							<p class="footer-company-about">
							<span>A propos du site</span>
							Bienvenue dans votre médiathèque! H2m est une médiathèque ouverte à tous public, elle vous
							offre plusieurs services et vous permet de rester en contact avec la littérature et la culture.
							</p>

					</div>

</footer>
  </body>
  
 </html>
