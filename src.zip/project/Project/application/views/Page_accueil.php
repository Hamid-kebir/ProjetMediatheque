<?php $this->load->view("includes/header"); ?>



	
								<div >
											
                                                                    <header class="emplacement">
												<div>
												<p> Vous êtes ici : Accueil >  </p>
												</div>
								</div>

								
								<table  width=100% >
										<tr align="center">
											<td> 
												<div>
													<header class="row">
														<div class="livre">
															<h3 class="deco"> Livres </h3>
															<a href=""  target="_blank">
																<img src="<?=  base_url("template/livre.jpg")?>" alt="Livre" class="photo-ressource">
															</a>
														</div>
												</div>
											</td>

											<td>
												<div>
													<header class="row">
														<div class="cd">
															<h3 class="deco"> CD's & DVD's </h3>
															<a href=""  target="_blank">
																<img src="<?=  base_url("template/cd.jpg")?>" alt="Cd" class="photo-ressource">
															</a>
														</div>
												</div>	
											</td>
		
											<td >
												<div >
													<header class="row">
														<div class="info-pratique" >
															<p> Infos Pratiques </p>
														</div>
														
												<div >
													<header class="row">
														<div class="info-pratique-detail">
															<h3> Médiathèque : </h3>
															<a> Batiment 640 PUIO </a> <br>
															<a> 91940, Saclay </a> <br>
															<a> Téléphone: 06.51.38.54.42 </a> <br>
															<a> Email: abdelhamid.kebir@u-psud.fr </a> <br>
															<a href="https://www.google.fr/maps/place/P.U.I.O./@48.7103035,2.17091,17z/data=!3m1!4b1!4m5!3m4!1s0x47e67f4da135a5df:0x2b9d2ea38dcbf690!8m2!3d48.7103035!4d2.1730987" target="_blank">  Plan (PUIO) </a>
		  
												</div>
		
											</td>

										</tr>

										
										<tr align="center">
											<td>
												<div>
													<header class="row">
														<div class="musique">
															<h3 class="deco"> Musique </h3>
															<a href=""  target="_blank">
																<img src="<?=  base_url("template/musique.jpg")?>" alt="Musique" class="photo-ressource">
															</a>
														</div>
											</td>

											<td>
												<div>
													<header class="row">
														<div class="activite">
															<h3 class="deco"> Activités </h3>
															<a href=""  target="_blank">
																<img src="<?=  base_url("template/activite.jpg")?>" alt="Activite" class="photo-ressource">
															</a>
														</div>
												</div>
											</td>
		
											<td>		
												<div >
													<header class="row">
														<div class="agenda">
															<p> Agenda</p>
												</div>

												<!-- Affichage du calendrier dans la page d'accueil -->
												<div class="calendrier">
													<div class="row">
														<div class="span12">
															<table class="table-condensed table-bordered " width="380px" align="right">
																<thead>
																	<tr>
																		<th colspan="7">
																			<span class="btn-group">
																				<a class="btn"><i class="icon-chevron-left"></i></a>
																				<a class="btn active">Mai 2018</a>
																				<a class="btn"><i class="icon-chevron-right"></i></a>
																			</span>
																		</th>
																	</tr>																	
																	<tr>
																		<th>Su</th>
																		<th>Mo</th>
																		<th>Tu</th>
																		<th>We</th>
																		<th>Th</th>
																		<th>Fr</th>
																		<th>Sa</th>
																	</tr>
																</thead>
																
																<tbody>
																	<tr>
																		<td class="muted">29</td>
																		<td class="muted">30</td>
																		<td class="muted">31</td>
																		<td>1</td>
																		<td>2</td>
																		<td>3</td>
																		<td>4</td>
																	</tr>
																	<tr>
																		<td>5</td>
																		<td>6</td>
																		<td>7</td>
																		<td>8</td>
																		<td>9</td>
																		<td>10</td>
																		<td>11</td>
																	</tr>
																	<tr>
																		<td>12</td>
																		<td>13</td>
																		<td>14</td>
																		<td>15</td>
																		<td>16</td>
																		<td>17</td>
																		<td class="btn-primary"> <strong> 18 </strong></td>
																	</tr>
																	<tr>
																		<td>19</td>
																		<td>20</td>
																		<td>21</td>
																		<td>22</td>
																		<td>23</td>
																		<td>24</td>
																		<td>25</td>
																	</tr>
																	<tr>
																		<td>26</td>
																		<td>27</td>
																		<td>28</td>
																		<td>29</td>
																		<td class="muted">1</td>
																		<td class="muted">2</td>
																		<td class="muted">3</td>
																	</tr>
																</tbody>
															</table>
														</div>
													</div>
												</div>	
											</td>
										</tr>
								</table>



    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>

<!-- Footer   -->	
<footer class="footer-distributed">

					<div class="footer-left">

							<h3>Médiathèque<span>H2M</span></h3>

							<p class="footer-links">
							
								<a href="#">Accueil</a>
					
								<a href="#">A propos</a>
					
								<a href="#">FAQ</a>
					
								<a href="#">Contact</a>
							</p>

							<p class="footer-company-name">H2M Médiathèque &copy; 2018</p>
					</div>

					<div class="footer-center">

						<div>
							<i class="fa fa-map-marker"></i>
							<p><span>Batiment 640 PUIO</span> Saclay, France</p>
						</div>

						<div>
							<i class="fa fa-phone"></i>
							<p>+33 7 52 82 54 62</p>
						</div>

						<div>
							<i class="fa fa-envelope"></i>
							<p><a href="mailto:echaimae.ou@gmail.com">echaimae.ou@gmail.com </a></p>
						</div>

					</div>

					<div class="footer-right">

							<p class="footer-company-about">
							<span>A propos du site</span>
							Bienvenue dans votre médiathèque! H2m est une médiathèque ouverte à tous public, elle vous
							offre plusieurs services et vous permet de rester en contact avec la littérature et la culture.
							</p>


					</div>

</footer>
</html>
