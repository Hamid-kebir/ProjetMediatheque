<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="icone_h2m.jpg">

  
    <!-- Custom styles for this template -->
    <link href="starter-template.css" rel="stylesheet">
	<link href="bootstrap.css" rel="stylesheet">
	<link href="assets/css/font-awesome.css" rel="stylesheet">
	<script src="jquery.js"></script>
	<script src="bootstrap.min.js"></script>
	<script src="assets/js/jquery-1.11.1.js"></script>
	<script src="assets/js/custom.js"></script>

	
	<!-->
    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
  </head>
  
  <body>
					<h1 class="titre_iframe"> Gestion des notifications </h1>
           
                                        <?php
                                        
                                       // echo "<pre>";
                                       // print_r($notfications);
                                        ?>
                                        
<table class="table table-bordered">
    <thead>
      <tr>
        <th>Abonné</th>
        <th>Livre (Nom)</th>
        <th>Livre (Prix)</th>
        <th>Tel</th>
        <th>Type de reservation</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
        <?php foreach ($notfications AS $notification){ ?>
      <tr>
        <td><?=$notification->Nom." ".$notification->Prenom?></td>
        <td><?=$notification->titre." (".$notification->id_ressource.")"?></td>
        <td><?=$notification->Tel?> Euro</td>
        <td><?=$notification->Prix?> Euro</td>
        <td>
            <?php
                    
                    if(isset($notification->id_fiche_reservation)){
                        echo "Reservation";
                    }else if(isset($notification->id_fiche_emprunt)){
                        echo "Emprunt";
                    }else if(isset($notification->id_fiche_achat)){
                        echo "Achat";
                    }
            
            ?>
        </td>
        <td>
            <?php
            if($notification->confim==0){
                echo '<a href="'.  site_url("admin/bibliothecaire/gestion_notification?id_fiche=".$notification->id_fiche).'">Confirmer</a>';
            }
        
        ?></td>
      </tr>
      
        <?php } ?>
     
    </tbody>
  </table>
					
					
  </body>
  </html>
