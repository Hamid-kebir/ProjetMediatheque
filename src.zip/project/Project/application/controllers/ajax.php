<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

    
    public function ajoutResource(){
        
         if($this->input->post("do")=="Ajouter"){
             echo json_encode($this->admin->ajoutResource());
         }else{
             echo json_encode(array("success"=>0));
         }
            
        
    }


    public function inscription()
      {
          echo json_encode($this->abonnee->inscription());
      }
      
      
      public function login()
      {
            echo json_encode($this->abonnee->login());
      }
      
       public function reserver()
      {
           echo json_encode($this->livre->reserver());
      }
      
       public function achter()
      {
           echo json_encode($this->livre->achter());
      }
      
      
      
      public function emprunter()
      {
           echo json_encode($this->livre->emprunter());
      }
      
      
      
    
      
      
        
        
        
}
