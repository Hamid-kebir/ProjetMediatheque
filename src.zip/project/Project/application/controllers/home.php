<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    
    
    /*
    public function reserver_ressource()
      {
        
        
        $this->load->view('reserver_ressource',$data);
      }
      public function acheter_ressource()
      {
          
          $data['res_data'] = $this->livre->getRes();
        $this->load->view('acheter_ressource',$data);
      }
    
      public function emprunter_ressource()
      {
          
          $data['res_data'] = $this->livre->getRes();
        $this->load->view('emprunter_ressource',$data);
      }
     * */
    
    
      public function index()
      {
        $this->load->view('Page_accueil');
      }
      
      
      public function detail()
      {
          
          if(isLogged($this)){
                $data['res_data'] = $this->livre->getRes();

                if(!empty($data['res_data']))
                  $this->load->view('page_client',$data);
                else{
                    redirect("home/resultat");
                }
          }
      }
      
      
      public function resultat()
      {
          
          $this->load->model("livre");
          
          $data['result'] = $this->livre->obtenirListeLivres();
            $this->load->view('Listing',$data);
      }
      
      
      
      public function horaire()
      {
        $this->load->view('horaire');
      }
      
      public function venir()
      {
        $this->load->view('venir');
      }
      
      public function coordonnees()
      {
        $this->load->view('coordonnees');
      }
    
      public function document_admin()
      {
        $this->load->view('document_admin');
      }
      
      public function rayon()
      {
        $this->load->view('rayon');
      }
      
      public function mission()
      {
        $this->load->view('mission');
      }
      
      
      
      
      public function deconnecter(){
          
          unset($_SESSION['user']);
         
          redirect("");
          
      }
      
      
        
        
        
}
