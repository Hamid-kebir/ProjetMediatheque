<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    
    
    
      public function index()
      {
        $this->load->view('page_administrateur');
      }
      
      
     
      
      
      public function bibliothecaire()
      {
         $data['notfications'] = $this->madmin->listeReservation();
         $this->madmin->confirm();
          
        $this->load->view('page_bibliothecaire',$data);
      }
      
      public function gestion_bibliothecaire()
      {
        $this->load->view('gestion_bibliothecaire');
      }
      
      public function gestion_ressource()
      {
         
          $this->load->view('gestion_ressource');
      }
      
      public function gestion_fiche()
      {
        $this->load->view('gestion_fiche');
      }
      
      public function gestion_facture()
      {
        $this->load->view('gestion_facture');
      }
      
      public function gestion_activite()
      {
        $this->load->view('gestion_activite');
      }
      
      
      
      public function secretaire()
      {
        $this->load->view('page_secretaire');
      }
      
      
    
      
      
        
        
        
}
